# Sesión 07 · Base de datos NoSQL en MongoDB

**SENA CADPH Garzón · ADSO — Desarrollo Web Full Stack MERN**

Proyecto **mi-proyecto-adso** completo al cierre de la Sesión 07. Incluye todo lo construido desde la Sesión 06.

Colección polimórfica contents (banners, servicios, testimonios y métricas) con validador, 5 índices y semilla en Extended JSON.

## Cómo usarlo (PowerShell)

```powershell
Compass → base adso_polyglot_db → colección contents → Add Data → Import JSON → database/nosql/01_content_seed.json
o bien:  mongosh "<su MONGO_URI>" --file database/nosql/01_adso_polyglot_setup.js
```

## Contenido

- `database/migrations/01_auth_schema.sql`
- `database/nosql/01_adso_polyglot_setup.js`
- `database/nosql/01_content_seed.json`
- `database/seeds/01_test_seed.sql`
- `docs/sesion-06-INSTRUCCIONES.md`
- `docs/sesion-07-INSTRUCCIONES.md`

## Importante

- Este paquete sirve para **ponerse al día o comparar** con su propio montaje. La evidencia de la sesión sigue siendo **su repositorio personal en GitHub con sus propios commits**.
- `server/.env` nunca viene en el paquete ni se sube a GitHub: créelo a partir de `server/.env.example`.
- Las contraseñas de la semilla (`Admin2026*`, `Aprendiz2026*`) son públicas y **solo para desarrollo local**.
