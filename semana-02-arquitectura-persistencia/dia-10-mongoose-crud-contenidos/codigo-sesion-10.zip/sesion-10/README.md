# Sesión 10 · Mongoose y CRUD del catálogo

**SENA CADPH Garzón · ADSO — Desarrollo Web Full Stack MERN**

Archivos que la **Sesión 10** agrega o modifica en mi-proyecto-adso. Cópielos sobre su proyecto respetando las mismas rutas.

Modelo Content con discriminators, GET /api/content/published, CRUD de laboratorio con campos protegidos, defensa contra inyección NoSQL y colección Bruno de 12 casos.

## Cómo usarlo (PowerShell)

```powershell
cd server ; npm run dev
Abra http://localhost:3000/api/content/published
Bruno → Open Collection → server/bruno-catalogo → Run Collection
```

## Contenido

- `docs/sesion-10-INSTRUCCIONES.md`
- `server/bruno-catalogo/01 - Contenidos Publicados (200 OK).bru`
- `server/bruno-catalogo/02 - Publicados por Tipo (200 OK).bru`
- `server/bruno-catalogo/03 - Inyección NoSQL en Tipo (400 Bad Request).bru`
- `server/bruno-catalogo/04 - Límite Fuera de Rango (400 Bad Request).bru`
- `server/bruno-catalogo/05 - Crear Servicio en Borrador (201 Created).bru`
- `server/bruno-catalogo/06 - Banner con Enlace JavaScript Malicioso (400 Bad Request).bru`
- `server/bruno-catalogo/07 - Código de Servicio Duplicado (409 Conflict).bru`
- `server/bruno-catalogo/08 - Publicar Contenido (200 OK).bru`
- `server/bruno-catalogo/09 - Cambiar Tipo (422 Unprocessable Entity).bru`
- `server/bruno-catalogo/10 - Listado Admin de Borradores (200 OK).bru`
- `server/bruno-catalogo/11 - Eliminar Contenido (204 No Content).bru`
- `server/bruno-catalogo/12 - Eliminar de Nuevo (404 Not Found).bru`
- `server/bruno-catalogo/bruno.json`
- `server/bruno-catalogo/environments/Local.bru`
- `server/src/app.js`
- `server/src/config/db.js`
- `server/src/controllers/contentController.js`
- `server/src/middlewares/errorHandler.js`
- `server/src/models/Content.js`
- `server/src/routes/contentRoutes.js`
- `server/src/routes/devContentRoutes.js`
- `server/src/utils/validators.js`

## Importante

- Este paquete sirve para **ponerse al día o comparar** con su propio montaje. La evidencia de la sesión sigue siendo **su repositorio personal en GitHub con sus propios commits**.
- `server/.env` nunca viene en el paquete ni se sube a GitHub: créelo a partir de `server/.env.example`.
- Las contraseñas de la semilla (`Admin2026*`, `Aprendiz2026*`) son públicas y **solo para desarrollo local**.
