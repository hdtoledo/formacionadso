# Sesión 10 · Mongoose y CRUD del catálogo

**SENA CADPH Garzón · ADSO — Desarrollo Web Full Stack MERN**

Proyecto **mi-proyecto-adso** completo al cierre de la Sesión 10. Incluye todo lo construido desde la Sesión 06.

Modelo Content con discriminators, GET /api/content/published, CRUD de laboratorio con campos protegidos, defensa contra inyección NoSQL y colección Bruno de 12 casos.

## Cómo usarlo (PowerShell)

```powershell
cd server ; npm run dev
Abra http://localhost:3000/api/content/published
Bruno → Open Collection → server/bruno-catalogo → Run Collection
```

## Contenido

- `database/migrations/01_auth_schema.sql`
- `database/migrations/02_hardening_auth_schema.sql`
- `database/nosql/01_adso_polyglot_setup.js`
- `database/nosql/01_content_seed.json`
- `database/seeds/01_test_seed.sql`
- `database/seeds/02_fix_seed_credentials.sql`
- `database/seeds/99_reset_pruebas_sesion_09.sql`
- `docs/sesion-06-INSTRUCCIONES.md`
- `docs/sesion-07-INSTRUCCIONES.md`
- `docs/sesion-08-INSTRUCCIONES.md`
- `docs/sesion-09-INSTRUCCIONES.md`
- `docs/sesion-10-INSTRUCCIONES.md`
- `server/.env.example`
- `server/.gitignore`
- `server/bruno-catalogo/01 - Contenidos Publicados (200 OK).bru`
- `server/bruno-catalogo/02 - Publicados por Tipo (200 OK).bru`
- `server/bruno-catalogo/03 - Inyección NoSQL en Tipo (400 Bad Request).bru`
- `server/bruno-catalogo/04 - Límite Fuera de Rango (400 Bad Request).bru`
- `server/bruno-catalogo/05 - Crear Servicio en Borrador (201 Created).bru`
- `server/bruno-catalogo/06 - Banner con Enlace JavaScript Malicioso (400 Bad Request).bru`
- `server/bruno-catalogo/07 - Código de Servicio Duplicado (409 Conflict).bru`
- `server/bruno-catalogo/08 - Listado Admin de Borradores (200 OK).bru`
- `server/bruno-catalogo/09 - Publicar Contenido (200 OK).bru`
- `server/bruno-catalogo/10 - Cambiar Tipo (422 Unprocessable Entity).bru`
- `server/bruno-catalogo/11 - Eliminar Contenido (204 No Content).bru`
- `server/bruno-catalogo/12 - Eliminar de Nuevo (404 Not Found).bru`
- `server/bruno-catalogo/bruno.json`
- `server/bruno-catalogo/environments/Local.bru`
- `server/bruno/01 - Health Check.bru`
- `server/bruno/02 - Crear Usuario (201 Created).bru`
- `server/bruno/03 - Crear Duplicado en Mayúsculas (409 Conflict).bru`
- `server/bruno/04 - Asignación Masiva de Rol (role ignorado).bru`
- `server/bruno/05 - Correo Inválido (400 Bad Request).bru`
- `server/bruno/06 - Buscar por Email (200 OK).bru`
- `server/bruno/07 - Inyección SQL en Email (404 Not Found).bru`
- `server/bruno/08 - Buscar por ID Inválido (400 Bad Request).bru`
- `server/bruno/09 - Buscar por ID (200 OK).bru`
- `server/bruno/10 - Verificar Cuenta (200 OK · Transacción).bru`
- `server/bruno/11 - Re-verificar Cuenta (409 Conflict).bru`
- `server/bruno/bruno.json`
- `server/bruno/environments/Local.bru`
- `server/package.json`
- `server/src/app.js`
- `server/src/config/db.js`
- `server/src/config/environment.js`
- `server/src/controllers/contentController.js`
- `server/src/controllers/devUserController.js`
- `server/src/controllers/healthController.js`
- `server/src/middlewares/asyncHandler.js`
- `server/src/middlewares/errorHandler.js`
- `server/src/models/Content.js`
- `server/src/repositories/UserRepository.js`
- `server/src/routes/contentRoutes.js`
- `server/src/routes/devContentRoutes.js`
- `server/src/routes/devUserRoutes.js`
- `server/src/routes/healthRoutes.js`
- `server/src/server.js`
- `server/src/utils/validators.js`

## Importante

- Este paquete sirve para **ponerse al día o comparar** con su propio montaje. La evidencia de la sesión sigue siendo **su repositorio personal en GitHub con sus propios commits**.
- `server/.env` nunca viene en el paquete ni se sube a GitHub: créelo a partir de `server/.env.example`.
- Las contraseñas de la semilla (`Admin2026*`, `Aprendiz2026*`) son públicas y **solo para desarrollo local**.
