# Sesión 08 · Backend Express en capas con conexión dual

**SENA CADPH Garzón · ADSO — Desarrollo Web Full Stack MERN**

Archivos que la **Sesión 08** agrega o modifica en mi-proyecto-adso. Cópielos sobre su proyecto respetando las mismas rutas.

Servidor Express (ES Modules) con pool de PostgreSQL, singleton de Mongoose, variables fail-fast, CORS con CLIENT_URL, errores estándar y GET /api/health.

## Cómo usarlo (PowerShell)

```powershell
cd server
npm install
Copy-Item .env.example .env   # complete PG_PASSWORD y MONGO_URI
npm run dev   # luego abra http://localhost:3000/api/health
```

## Contenido

- `docs/sesion-08-INSTRUCCIONES.md`
- `server/.env.example`
- `server/.gitignore`
- `server/package.json`
- `server/src/app.js`
- `server/src/config/db.js`
- `server/src/config/environment.js`
- `server/src/controllers/healthController.js`
- `server/src/middlewares/errorHandler.js`
- `server/src/routes/healthRoutes.js`
- `server/src/server.js`

## Importante

- Este paquete sirve para **ponerse al día o comparar** con su propio montaje. La evidencia de la sesión sigue siendo **su repositorio personal en GitHub con sus propios commits**.
- `server/.env` nunca viene en el paquete ni se sube a GitHub: créelo a partir de `server/.env.example`.
- Las contraseñas de la semilla (`Admin2026*`, `Aprendiz2026*`) son públicas y **solo para desarrollo local**.
