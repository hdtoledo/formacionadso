# Sesión 09 · UserRepository y prevención de inyección SQL

**SENA CADPH Garzón · ADSO — Desarrollo Web Full Stack MERN**

Proyecto **mi-proyecto-adso** completo al cierre de la Sesión 09. Incluye todo lo construido desde la Sesión 06.

Repositorio con consultas parametrizadas, transacción de verificación, rutas de laboratorio /api/dev/users, migración 02 y colección Bruno de 11 casos.

## Cómo usarlo (PowerShell)

```powershell
psql -U postgres -d adso_auth_db -f database/migrations/02_hardening_auth_schema.sql   # solo si su esquema es anterior
psql -U postgres -d adso_auth_db -f database/seeds/02_fix_seed_credentials.sql
cd server ; npm run dev
Bruno → Open Collection → server/bruno → Run Collection
```

## Contenido

- `database/migrations/01_auth_schema.sql`
- `database/migrations/02_hardening_auth_schema.sql`
- `database/nosql/01_adso_polyglot_setup.js`
- `database/nosql/01_content_seed.json`
- `database/seeds/01_test_seed.sql`
- `database/seeds/02_fix_seed_credentials.sql`
- `database/seeds/99_reset_pruebas_sesion_09.sql`
- `docs/sesion-06-INSTRUCCIONES.md`
- `docs/sesion-07-INSTRUCCIONES.md`
- `docs/sesion-08-INSTRUCCIONES.md`
- `docs/sesion-09-INSTRUCCIONES.md`
- `server/.env.example`
- `server/.gitignore`
- `server/bruno/01 - Health Check.bru`
- `server/bruno/02 - Crear Usuario (201 Created).bru`
- `server/bruno/03 - Crear Duplicado en Mayúsculas (409 Conflict).bru`
- `server/bruno/04 - Asignación Masiva de Rol (role ignorado).bru`
- `server/bruno/05 - Correo Inválido (400 Bad Request).bru`
- `server/bruno/06 - Buscar por Email (200 OK).bru`
- `server/bruno/07 - Inyección SQL en Email (404 Not Found).bru`
- `server/bruno/08 - Buscar por ID Inválido (400 Bad Request).bru`
- `server/bruno/09 - Buscar por ID (200 OK).bru`
- `server/bruno/10 - Verificar Cuenta (200 OK · Transacción).bru`
- `server/bruno/11 - Re-verificar Cuenta (409 Conflict).bru`
- `server/bruno/bruno.json`
- `server/bruno/environments/Local.bru`
- `server/package.json`
- `server/src/app.js`
- `server/src/config/db.js`
- `server/src/config/environment.js`
- `server/src/controllers/devUserController.js`
- `server/src/controllers/healthController.js`
- `server/src/middlewares/asyncHandler.js`
- `server/src/middlewares/errorHandler.js`
- `server/src/repositories/UserRepository.js`
- `server/src/routes/devUserRoutes.js`
- `server/src/routes/healthRoutes.js`
- `server/src/server.js`
- `server/src/utils/validators.js`

## Importante

- Este paquete sirve para **ponerse al día o comparar** con su propio montaje. La evidencia de la sesión sigue siendo **su repositorio personal en GitHub con sus propios commits**.
- `server/.env` nunca viene en el paquete ni se sube a GitHub: créelo a partir de `server/.env.example`.
- Las contraseñas de la semilla (`Admin2026*`, `Aprendiz2026*`) son públicas y **solo para desarrollo local**.
