# Sesión 06 · Base de datos relacional en PostgreSQL

**SENA CADPH Garzón · ADSO — Desarrollo Web Full Stack MERN**

Proyecto **mi-proyecto-adso** completo al cierre de la Sesión 06. Incluye todo lo construido desde la Sesión 06.

Tablas users y verification_tokens con UUID, token_hash SHA-256, trigger updated_at, índice de la llave foránea y semilla con hashes bcrypt reales.

## Cómo usarlo (PowerShell)

```powershell
psql -U postgres -c "CREATE DATABASE adso_auth_db;"
psql -U postgres -d adso_auth_db -f database/migrations/01_auth_schema.sql
psql -U postgres -d adso_auth_db -f database/seeds/01_test_seed.sql
```

## Contenido

- `database/migrations/01_auth_schema.sql`
- `database/seeds/01_test_seed.sql`
- `docs/sesion-06-INSTRUCCIONES.md`

## Importante

- Este paquete sirve para **ponerse al día o comparar** con su propio montaje. La evidencia de la sesión sigue siendo **su repositorio personal en GitHub con sus propios commits**.
- `server/.env` nunca viene en el paquete ni se sube a GitHub: créelo a partir de `server/.env.example`.
- Las contraseñas de la semilla (`Admin2026*`, `Aprendiz2026*`) son públicas y **solo para desarrollo local**.
